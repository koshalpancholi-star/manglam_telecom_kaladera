
document.addEventListener("DOMContentLoaded", () => {
    const preloader = document.getElementById('preloader');
    if (preloader) {
        setTimeout(() => {
            preloader.style.opacity = '0';
            setTimeout(() => { preloader.style.display = 'none'; }, 500);
        }, 800);
    }

    document.addEventListener('mousemove', (e) => {
        document.body.style.setProperty('--mouse-x', `${e.clientX}px`);
        document.body.style.setProperty('--mouse-y', `${e.clientY}px`);
    });

    const counters = document.querySelectorAll('.counter');
    counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        let count = 0;
        const inc = target / 100;
        const update = () => {
            if(count < target) {
                count += inc;
                counter.innerText = Math.ceil(count);
                setTimeout(update, 15);
            } else {
                counter.innerText = target;
            }
        };
        update();
    });

    const backToTop = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
        if(window.scrollY > 300) backToTop.classList.add('visible');
        else backToTop.classList.remove('visible');
    });
});
