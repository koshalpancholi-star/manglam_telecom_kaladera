
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const brandFilter = document.getElementById('brandFilter');
    const budgetFilter = document.getElementById('budgetFilter');
    const products = document.querySelectorAll('.product-card');

    const filter = () => {
        const query = searchInput.value.toLowerCase();
        const brand = brandFilter.value;
        const budget = budgetFilter.value;

        products.forEach(product => {
            const name = product.querySelector('h3').innerText.toLowerCase();
            const pBrand = product.getAttribute('data-brand');
            const pPrice = product.getAttribute('data-price');

            const matchQuery = name.includes(query);
            const matchBrand = brand === 'all' || pBrand === brand;
            const matchBudget = budget === 'all' || pPrice === budget;

            if(matchQuery && matchBrand && matchBudget) {
                product.style.display = 'block';
            } else {
                product.style.display = 'none';
            }
        });
    };

    searchInput.addEventListener('input', filter);
    brandFilter.addEventListener('change', filter);
    budgetFilter.addEventListener('change', filter);
});
